#ifndef DUNEURO_DEPRECATED_HH
#define DUNEURO_DEPRECATED_HH

#include <string>

namespace duneuro
{
  void issueDeprecationWarning(const std::string& msg);
}

#endif // DUNEURO_DEPRECATED_HH
