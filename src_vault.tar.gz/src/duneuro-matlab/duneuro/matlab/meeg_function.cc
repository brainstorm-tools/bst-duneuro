#include <config.h>

#include <duneuro/matlab/meeg_function.hh>

#include <duneuro/common/function.hh>
