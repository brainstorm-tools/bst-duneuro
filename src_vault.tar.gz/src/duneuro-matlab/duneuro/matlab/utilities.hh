#ifndef DUNEURO_MATLAB_UTILITIES_HH
#define DUNEURO_MATLAB_UTILITIES_HH

#include <mex.h>

#include <duneuro/common/dense_matrix.hh>
#include <duneuro/matlab/meeg_driver.hh>

namespace duneuro
{
  /** \TODO docme! */
  template <class T>
  mxArray* convert_ptr_to_mat(T* ptr)
  {
    mxArray* out = mxCreateNumericMatrix(1, 1, mxUINT64_CLASS, mxREAL);
    *((uint64_t*) mxGetData(out)) = reinterpret_cast<uint64_t>(ptr);
    return out;
  }

  /** \TODO docme! */
  template <class T>
  T* convert_mat_to_ptr(const mxArray* in)
  {
    if (mxGetNumberOfElements(in) != 1 || mxGetClassID(in) != mxUINT64_CLASS || mxIsComplex(in))
      mexErrMsgTxt("Input must be a real uint64 scalar.");
    return reinterpret_cast<T*>(*((uint64_t*) mxGetData(in)));
  }

  std::map<std::string, std::string> matlab_struct_to_map(const mxArray* mstr);

  template <int N>
  std::array<double, N> extract_double_array(const mxArray* arr)
  {
    if (!mxIsDouble(arr)) {
      mexErrMsgTxt("expected double matrix for dipole");
    }
    int count = mxGetNumberOfElements(arr);
    if (count != N) {
      mexErrMsgTxt("illegal number of elements");
    }
    const double* ptr = mxGetPr(arr);
    std::array<double, N> result;
    std::copy(ptr, ptr + N, result.begin());
    return result;
  }

  template <int N>
  std::vector<std::array<double, N>> extract_double_arrays(const mxArray* arr)
  {
    if (!mxIsDouble(arr)) {
      mexErrMsgTxt("expected double matrix for electrodes");
    }
    int rows = mxGetM(arr);
    int cols = mxGetN(arr);
    if (rows != N) {
      mexErrMsgTxt("illegal number of rows.");
    }
    const double* ptr = mxGetPr(arr);
    std::vector<std::array<double, N>> output;
    for (int i = 0; i < cols; ++i, ptr += rows) {
      std::array<double, N> v;
      std::copy(ptr, ptr + rows, v.begin());
      output.push_back(v);
    }
    return output;
  }

  template <int N>
  std::vector<std::vector<std::array<double, 3>>> extract_projections(const mxArray* arr)
  {
    if (!mxIsDouble(arr)) {
      mexErrMsgTxt("expected double matrix for projections");
    }
    int rows = mxGetM(arr);
    int cols = mxGetN(arr);
    if (rows % N != 0) {
      mexErrMsgTxt(
          "number of rows has to be the a multiple of the number of entries of each projection");
    }
    const double* ptr = mxGetPr(arr);
    std::vector<std::vector<std::array<double, N>>> output;
    for (int i = 0; i < cols; ++i, ptr += rows) {
      std::vector<std::array<double, N>> current;
      for (int j = 0; j < rows; j += N) {
        std::array<double, N> v;
        std::copy(ptr + j, ptr + j + N, v.begin());
        current.push_back(v);
      }
      output.push_back(current);
    }
    return output;
  }

  /** \TODO docme! */
  std::unique_ptr<const DenseMatrix<double>> extract_dense_matrix(mxArray* arr);

  /** \TODO docme! */
  bool extract_bool(const mxArray* arr);

  void extract_fitted_driver_data_from_struct(const mxArray* str,
                                              duneuro::matlab::MEEGDriverData& data);
}

#endif // DUNEURO_MATLAB_UTILITIES_HH
