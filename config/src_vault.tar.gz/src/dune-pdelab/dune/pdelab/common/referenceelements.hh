#ifndef DUNE_PDELAB_COMMON_REFERENCEELEMENTS_HH
#define DUNE_PDELAB_COMMON_REFERENCEELEMENTS_HH

#include <dune/geometry/referenceelements.hh>

#warning The header file dune/pdelab/common/referenceelements.hh is deprecated, please use dune/geometry/referenceelements.hh instead.

#endif // DUNE_PDELAB_COMMON_REFERENCEELEMENTS_HH
