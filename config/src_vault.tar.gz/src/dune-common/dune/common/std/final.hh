#ifndef DUNE_COMMON_STD_FINAL_HH
#define DUNE_COMMON_STD_FINAL_HH

#warning The header dune/common/std/final.hh is deprecated. Remove the include and use "final".

#define DUNE_FINAL final

#endif   // DUNE_COMMON_STD_FINAL_HH
