#ifndef DUNE_COMMON_STD_CONSTEXPR_HH
#define DUNE_COMMON_STD_CONSTEXPR_HH

#warning The header dune/common/std/constexpr.hh is deprecated. Remove the include and use "constexpr".

#define DUNE_CONSTEXPR constexpr

#endif // #ifndef DUNE_COMMON_STD_CONSTEXPR_HH
