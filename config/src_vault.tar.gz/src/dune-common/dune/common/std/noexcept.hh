#ifndef DUNE_COMMON_STD_NOEXCEPT_HH
#define DUNE_COMMON_STD_NOEXCEPT_HH

#warning The header dune/common/std/noexcept.hh is deprecated. Remove the include and use "noexcept".

#define DUNE_NOEXCEPT noexcept

#endif // DUNE_COMMON_STD_NOEXCEPT_HH
