// -*- tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 2 -*-
// vi: set et ts=4 sw=2 sts=2:
#ifndef DUNE_NULLPTR_HH
#define DUNE_NULLPTR_HH

#include <cstddef>

namespace Dune {
  using std::nullptr_t;
}

#warning The header dune/common/nullptr.hh is deprecated. Just remove the include.

#endif // DUNE_NULLPTR_HH
