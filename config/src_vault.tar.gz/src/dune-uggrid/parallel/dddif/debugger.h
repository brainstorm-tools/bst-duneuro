// -*- tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 2 -*-
// vi: set et ts=4 sw=2 sts=2:
#ifndef __DDD_DEBUGGER__
#define __DDD_DEBUGGER__

#include "namespace.h"

START_UGDIM_NAMESPACE
void buggy (MULTIGRID *);
void dddif_PrintGridRelations (MULTIGRID *);
END_UGDIM_NAMESPACE


#endif
