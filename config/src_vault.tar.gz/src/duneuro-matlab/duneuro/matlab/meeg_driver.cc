#include <config.h>

#include <duneuro/matlab/meeg_driver.hh>

#include <dune/common/parametertree.hh>

#include <duneuro/meeg/meeg_driver_factory.hh>

namespace duneuro
{
  namespace matlab
  {
    namespace MEEGDriverDetail
    {
      static inline Dune::ParameterTree
      toParameterTree(const std::map<std::string, std::string>& cfg)
      {
        Dune::ParameterTree ptree;
        for (const auto& k : cfg) {
          ptree[k.first] = k.second;
        }
        return ptree;
      }
    }

    MEEGDriver::MEEGDriver(const Config& config, const MEEGDriverData& data)
    {
      duneuro::MEEGDriverData<3> ddata;
      ddata.fittedData.elements = data.elements;
      ddata.fittedData.labels = data.labels;
      ddata.fittedData.conductivities = data.conductivities;
      ddata.fittedData.nodes.reserve(data.nodes.size());
      for (const auto& n : data.nodes) {
        Dune::FieldVector<double, 3> current;
        std::copy(n.begin(), n.end(), current.begin());
        ddata.fittedData.nodes.push_back(current);
      }
      ddata.fittedData.tensors.reserve(data.tensors.size());
      for (const auto& t : data.tensors) {
        Dune::FieldMatrix<double, 3, 3> m;
        for (unsigned int i = 0; i < 3; ++i)
          for (unsigned int j = 0; j < 3; ++j)
            m[i][j] = t[i][j];
        ddata.fittedData.tensors.push_back(m);
      }
      this->driver_ =
          MEEGDriverFactory<3>::make_meeg_driver(MEEGDriverDetail::toParameterTree(config), ddata);
    }

    std::unique_ptr<duneuro::matlab::Function> MEEGDriver::makeDomainFunction() const
    {
      return {this->makeDomainFunction()};
    }

    void MEEGDriver::solveEEGForward(const std::array<double, 6>& dipole,
                                     duneuro::matlab::Function& solution, const Config& config)
    {
      Dune::FieldVector<double, 3> pos, mom;
      std::copy(dipole.begin(), dipole.begin() + 3, pos.begin());
      std::copy(dipole.begin() + 3, dipole.end(), mom.begin());
      this->driver_->solveEEGForward({pos, mom}, *solution.function,
                                     MEEGDriverDetail::toParameterTree(config));
    }

    std::vector<double> MEEGDriver::solveMEGForward(const duneuro::matlab::Function& solution,
                                                    const Config& config)
    {
      return this->driver_->solveMEGForward(*solution.function,
                                            MEEGDriverDetail::toParameterTree(config));
    }

    std::unique_ptr<DenseMatrix<double>> MEEGDriver::computeEEGTransferMatrix(const Config& config)
    {
      return this->driver_->computeEEGTransferMatrix(MEEGDriverDetail::toParameterTree(config));
    }

    std::unique_ptr<DenseMatrix<double>> MEEGDriver::computeMEGTransferMatrix(const Config& config)
    {
      return this->driver_->computeMEGTransferMatrix(MEEGDriverDetail::toParameterTree(config));
    }

    std::vector<std::vector<double>>
    MEEGDriver::applyEEGTransfer(const DenseMatrix<double>& matrix,
                                 const std::vector<std::array<double, 6>>& dipoles,
                                 const Config& config)
    {
      std::vector<duneuro::Dipole<double, 3>> convertedDipoles;
      for (const auto& dipole : dipoles) {
        Dune::FieldVector<double, 3> pos, mom;
        std::copy(dipole.begin(), dipole.begin() + 3, pos.begin());
        std::copy(dipole.begin() + 3, dipole.end(), mom.begin());
        convertedDipoles.emplace_back(pos, mom);
      }
      return this->driver_->applyEEGTransfer(matrix, convertedDipoles,
                                             MEEGDriverDetail::toParameterTree(config));
    }

    std::vector<std::vector<double>>
    MEEGDriver::applyMEGTransfer(const DenseMatrix<double>& matrix,
                                 const std::vector<std::array<double, 6>>& dipoles,
                                 const Config& config)
    {
      std::vector<duneuro::Dipole<double, 3>> convertedDipoles;
      for (const auto& dipole : dipoles) {
        Dune::FieldVector<double, 3> pos, mom;
        std::copy(dipole.begin(), dipole.begin() + 3, pos.begin());
        std::copy(dipole.begin() + 3, dipole.end(), mom.begin());
        convertedDipoles.emplace_back(pos, mom);
      }
      return this->driver_->applyMEGTransfer(matrix, convertedDipoles,
                                             MEEGDriverDetail::toParameterTree(config));
    }

    void MEEGDriver::setElectrodes(const std::vector<std::array<double, 3>>& electrodes,
                                   const Config& config)
    {
      std::vector<Dune::FieldVector<double, 3>> elecs;
      for (const auto& e : electrodes) {
        Dune::FieldVector<double, 3> v;
        std::copy(e.begin(), e.end(), v.begin());
        elecs.push_back(v);
      }
      this->driver_->setElectrodes(elecs, MEEGDriverDetail::toParameterTree(config));
    }

    std::vector<std::array<double, 3>> MEEGDriver::getProjectedElectrodes()
    {
      std::vector<std::array<double, 3>> result;
      auto elecs = this->driver_->getProjectedElectrodes();
      for (const auto& e : elecs) {
        std::array<double, 3> v;
        std::copy(e.begin(), e.end(), v.begin());
        result.push_back(v);
      }
      return result;
    }

    void MEEGDriver::setCoilsAndProjections(
        const std::vector<std::array<double, 3>>& coils,
        const std::vector<std::vector<std::array<double, 3>>>& projections)
    {
      std::vector<Dune::FieldVector<double, 3>> ccoils;
      for (const auto& c : coils) {
        Dune::FieldVector<double, 3> v;
        std::copy(c.begin(), c.end(), v.begin());
        ccoils.push_back(v);
      }
      std::vector<std::vector<Dune::FieldVector<double, 3>>> pprojections;
      for (const auto& p : projections) {
        std::vector<Dune::FieldVector<double, 3>> c;
        for (const auto& e : p) {
          Dune::FieldVector<double, 3> v;
          std::copy(e.begin(), e.end(), v.begin());
          c.push_back(v);
        }
        pprojections.push_back(c);
      }
      this->driver_->setCoilsAndProjections(ccoils, pprojections);
    }

    std::vector<double> MEEGDriver::evaluateAtElectrodes(const duneuro::matlab::Function& function)
    {
      return this->driver_->evaluateAtElectrodes(*function.function);
    }

    void MEEGDriver::write(const Config& config)
    {
      this->driver_->write(MEEGDriverDetail::toParameterTree(config));
    }

    void MEEGDriver::write(const duneuro::matlab::Function& solution, const Config& config)
    {
      this->driver_->write(*solution.function, MEEGDriverDetail::toParameterTree(config));
    }
  }
}
