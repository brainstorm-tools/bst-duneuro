#ifndef DUNEURO_MATLAB_MEEG_FUNCTION_HH
#define DUNEURO_MATLAB_MEEG_FUNCTION_HH

#include <memory>

namespace duneuro
{
  class Function;
  namespace matlab
  {
    struct Function {
      std::shared_ptr<duneuro::Function> function;
    };
  }
}

#endif // DUNEURO_MATLAB_MEEG_FUNCTION_HH
