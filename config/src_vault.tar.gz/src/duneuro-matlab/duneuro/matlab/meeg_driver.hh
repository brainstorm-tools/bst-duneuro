#ifndef DUNEURO_MATLAB_MEEG_DRIVER_HH
#define DUNEURO_MATLAB_MEEG_DRIVER_HH

#include <map>
#include <memory>
#include <vector>

#include <duneuro/common/dense_matrix.hh>

#include <duneuro/matlab/meeg_function.hh>

namespace duneuro
{
  template <int dim>
  struct MEEGDriverInterface;

  namespace matlab
  {
    struct MEEGDriverData {
      using Coordinate = std::array<double, 3>;
      using Tensor = std::array<std::array<double, 3>, 3>;
      std::vector<Coordinate> nodes;
      std::vector<std::vector<unsigned int>> elements;
      std::vector<std::size_t> labels;
      std::vector<double> conductivities;
      std::vector<Tensor> tensors;
    };

    class MEEGDriver
    {
    public:
      using Config = std::map<std::string, std::string>;
      MEEGDriver(const Config& config, const MEEGDriverData& data);
      std::unique_ptr<duneuro::matlab::Function> makeDomainFunction() const;
      void solveEEGForward(const std::array<double, 6>& dipole, duneuro::matlab::Function& solution,
                           const Config& config);
      std::vector<double> solveMEGForward(const duneuro::matlab::Function& solution,
                                          const Config& config);
      std::unique_ptr<DenseMatrix<double>> computeEEGTransferMatrix(const Config& config);
      std::unique_ptr<DenseMatrix<double>> computeMEGTransferMatrix(const Config& config);
      std::vector<std::vector<double>>
      applyEEGTransfer(const DenseMatrix<double>& matrix,
                       const std::vector<std::array<double, 6>>& dipoles, const Config& config);
      std::vector<std::vector<double>>
      applyMEGTransfer(const DenseMatrix<double>& matrix,
                       const std::vector<std::array<double, 6>>& dipoles, const Config& config);
      void setElectrodes(const std::vector<std::array<double, 3>>& electrodes,
                         const Config& config);
      std::vector<std::array<double, 3>> getProjectedElectrodes();
      void
      setCoilsAndProjections(const std::vector<std::array<double, 3>>& coils,
                             const std::vector<std::vector<std::array<double, 3>>>& projections);
      std::vector<double> evaluateAtElectrodes(const duneuro::matlab::Function& function);
      void write(const Config& config);
      void write(const duneuro::matlab::Function& solution, const Config& config);
      std::unique_ptr<DenseMatrix<double>>
      analyticalSolution(const std::vector<std::array<double, 3>>& electrodes,
                         const std::vector<std::array<double, 6>>& dipoles, const Config& config);

      MEEGDriver(const MEEGDriver&) = delete;
      MEEGDriver(MEEGDriver&&) = delete;
      MEEGDriver& operator=(const MEEGDriver&) = delete;
      MEEGDriver& operator=(MEEGDriver&&) = delete;

    private:
      std::shared_ptr<MEEGDriverInterface<3>> driver_;
    };
  }
}

#endif // DUNEURO_MATLAB_MEEG_DRIVER_HH
