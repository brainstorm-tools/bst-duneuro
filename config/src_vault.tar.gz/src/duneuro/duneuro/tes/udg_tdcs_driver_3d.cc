

#include <config.h>

#include <duneuro/tes/udg_tdcs_driver.hh>

template class duneuro::UDGTDCSDriver<3, 1, 1>;
template class duneuro::UDGTDCSDriver<3, 1, 2>;
template class duneuro::UDGTDCSDriver<3, 1, 3>;
template class duneuro::UDGTDCSDriver<3, 1, 4>;
template class duneuro::UDGTDCSDriver<3, 1, 5>;
template class duneuro::UDGTDCSDriver<3, 1, 6>;
